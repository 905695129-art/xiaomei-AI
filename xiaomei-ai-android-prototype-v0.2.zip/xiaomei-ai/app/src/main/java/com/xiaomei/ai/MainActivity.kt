package com.xiaomei.ai

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(30), dp(22), dp(24))
            setBackgroundColor(0xFFFFF4F8.toInt())
        }
        root.addView(TextView(this).apply {
            text = "小美 AI  ✿\n智能聊天助手"
            textSize = 27f; setTextColor(0xFF9C4772.toInt())
        })
        root.addView(TextView(this).apply {
            text = "连接微信和抖音的新消息通知，在屏幕上弹出聊天分析与回复建议。"
            textSize = 15f; setTextColor(0xFF594A52.toInt()); setPadding(0, dp(14), 0, dp(16))
        })
        root.addView(Button(this).apply {
            text = "① 开启通知读取权限"
            setOnClickListener { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        })
        root.addView(Button(this).apply {
            text = "② 开启悬浮窗权限"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
            }
        })
        root.addView(TextView(this).apply {
            text = "使用步骤\n1. 在通知读取权限页面允许“小美AI”。\n2. 在悬浮窗权限页面允许“小美AI”显示在其他应用上层。\n3. 确保微信、抖音允许显示消息通知及内容预览。\n4. 收到新消息通知时，小美AI会尝试显示建议弹窗。\n\n隐私说明\n本测试版只处理 Android 通知实际提供的标题和文字，不进入微信或抖音内部读取聊天记录，不自动发送消息。通知若隐藏内容、仅显示“收到一条消息”或被系统折叠，助手无法分析具体文本。聊天建议目前由本地规则生成，尚未连接在线大模型。"
            textSize = 13f; setTextColor(0xFF725F69.toInt()); setPadding(0, dp(18), 0, dp(18))
        })

        root.addView(TextView(this).apply {
            text = "试用聊天建议（无需等待通知）"
            textSize = 16f; setTextColor(0xFF9C4772.toInt()); setPadding(0, dp(4), 0, dp(8))
        })
        val input = EditText(this).apply {
            hint = "粘贴一条收到的消息，例如：你怎么不主动找我？"
            minLines = 2; setTextSize(14f)
        }
        root.addView(input, ViewGroup.LayoutParams(-1, -2))
        val result = TextView(this).apply { textSize = 14f; setTextColor(0xFF594A52.toInt()); setPadding(0, dp(8), 0, dp(8)) }
        root.addView(Button(this).apply {
            text = "生成聊天建议"
            setOnClickListener {
                val content = input.text.toString().trim()
                result.text = if (content.isBlank()) "请先输入一条消息。" else {
                    val advice = ChatCoach.analyze(content)
                    "可能的沟通信号：${advice.insight}\n\n建议策略：${advice.strategy}\n\n" + advice.replies.mapIndexed { i, s -> "${i + 1}. ${advice.labels[i]}：$s" }.joinToString("\n\n")
                }
            }
        })
        root.addView(result)
        setContentView(root)
    }
}
