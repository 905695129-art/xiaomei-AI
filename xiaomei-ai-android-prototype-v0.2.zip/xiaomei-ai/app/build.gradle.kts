plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.xiaomei.ai"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.xiaomei.ai"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "0.2.0"
    }
}
