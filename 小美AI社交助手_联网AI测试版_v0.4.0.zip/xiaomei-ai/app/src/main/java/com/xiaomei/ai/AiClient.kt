package com.xiaomei.ai

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object AiClient {
    fun chat(endpoint: String, model: String, apiKey: String, message: String): String {
        require(endpoint.startsWith("https://") || endpoint.startsWith("http://10.") || endpoint.startsWith("http://192.168.")) { "接口地址必须使用 HTTPS（本地局域网测试除外）。" }
        require(model.isNotBlank()) { "请填写模型名称。" }
        require(apiKey.isNotBlank()) { "请填写 API Key。" }
        val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Authorization", "Bearer $apiKey")
        }
        try {
            val body = JSONObject().apply {
                put("model", model)
                put("messages", JSONArray().put(JSONObject().put("role", "system").put("content", "你是小美AI社交沟通助手。只提供尊重边界、真实自然、不骚扰他人的沟通建议。若对方明确拒绝或要求停止联系，建议停止联系。不要声称能确定对方真实想法。请给出简洁分析和三种可选回复。"))
                    .put(JSONObject().put("role", "user").put("content", message)))
                put("temperature", 0.7)
            }.toString()
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("接口返回 HTTP $code：${response.take(700)}")
            val json = JSONObject(response)
            return json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        } finally { conn.disconnect() }
    }
}
