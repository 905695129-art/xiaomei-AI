package com.xiaomei.ai

import android.app.Notification
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Reads only message text exposed by Android notifications. It never opens or scrapes chat apps. */
class MessageListener : NotificationListenerService() {
    private var windowManager: WindowManager? = null
    private var panel: android.view.View? = null
    private var lastFingerprint = ""
    private var lastShownAt = 0L
    private val supported = setOf("com.tencent.mm", "com.ss.android.ugc.aweme")

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in supported || sbn.isGroup || sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val body = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.trim().orEmpty()
        if (body.isBlank() || body.equals("你有一条新消息", true) || body.equals("[新消息]", true)) return
        // Avoid showing the same notification repeatedly when Android updates it.
        val fingerprint = "${sbn.packageName}|$title|$body"
        val now = System.currentTimeMillis()
        if (fingerprint == lastFingerprint && now - lastShownAt < 8_000) return
        lastFingerprint = fingerprint
        lastShownAt = now
        showSuggestion(if (title.isBlank()) "新消息" else title, body, sbn.packageName)
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun showSuggestion(sender: String, message: String, source: String) {
        if (!android.provider.Settings.canDrawOverlays(this)) return
        val appName = if (source == "com.tencent.mm") "微信" else "抖音"
        val analysis = ChatCoach.analyze(message)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(14))
            setBackgroundColor(0xFFFFF7FA.toInt())
            elevation = dp(12).toFloat()
        }
        root.addView(TextView(this).apply {
            text = "小美 AI  ✿   ${appName}新消息"
            textSize = 18f; setTextColor(0xFF9C4772.toInt())
        })
        root.addView(TextView(this).apply {
            text = "$sender：$message"
            textSize = 14f; setTextColor(0xFF51454B.toInt()); setPadding(0, dp(10), 0, dp(10))
        })
        root.addView(TextView(this).apply {
            text = "可能的沟通信号\n${analysis.insight}\n\n建议策略\n${analysis.strategy}"
            textSize = 14f; setTextColor(0xFF725363.toInt()); setPadding(0, 0, 0, dp(8))
        })
        analysis.replies.forEachIndexed { index, reply ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(8), dp(10), dp(8))
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            card.addView(TextView(this).apply {
                text = "${index + 1}. ${analysis.labels[index]}"
                textSize = 12f; setTextColor(0xFFB36B8D.toInt())
            })
            card.addView(TextView(this).apply {
                text = reply; textSize = 14f; setTextColor(0xFF443840.toInt()); setPadding(0, dp(4), 0, dp(4))
            })
            card.addView(Button(this).apply {
                text = "复制这条回复"
                setOnClickListener { copyReply(reply) }
            })
            val margin = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) }
            root.addView(card, margin)
        }
        root.addView(TextView(this).apply {
            text = "提示：以上是基于通知文字的辅助建议，不代表对方真实想法。发送前请按自己的实际感受修改。"
            textSize = 11f; setTextColor(0xFF927F89.toInt()); setPadding(0, dp(4), 0, dp(6))
        })
        root.addView(Button(this).apply { text = "关闭建议"; setOnClickListener { removePanel() } })

        removePanel()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val scroll = ScrollView(this).apply { addView(root) }
        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.92).toInt(),
            (resources.displayMetrics.heightPixels * 0.72).toInt(),
            type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(54) }
        try { panel = scroll; windowManager?.addView(scroll, params) } catch (_: Exception) { panel = null }
    }

    private fun copyReply(reply: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("小美AI回复", reply))
        removePanel()
    }

    private fun removePanel() {
        try { panel?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        panel = null
    }

    override fun onDestroy() { removePanel(); super.onDestroy() }
}
