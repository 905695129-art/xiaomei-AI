package com.xiaomei.ai

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.net.URL

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var endpoint: EditText
    private lateinit var model: EditText
    private lateinit var key: EditText
    private lateinit var input: EditText
    private lateinit var result: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("xiaomei", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            setBackgroundColor(0xFFFFF4F8.toInt())
        }
        root.addView(TextView(this).apply { text = "小美 AI  ✿\n智能社交助手"; textSize = 27f; setTextColor(0xFF9C4772.toInt()) })
        root.addView(TextView(this).apply {
            text = "联网版测试 0.4 · AI分析消息、生成沟通建议、辅助管理客户。发送消息仍由你确认。"
            textSize = 14f; setTextColor(0xFF594A52.toInt()); setPadding(0, dp(10), 0, dp(14))
        })
        root.addView(TextView(this).apply { text = "一、连接 AI 服务"; textSize = 18f; setTextColor(0xFF9C4772.toInt()) })
        endpoint = field("API 接口地址", prefs.getString("endpoint", "https://api.openai.com/v1/chat/completions") ?: "")
        model = field("模型名称（按服务商要求填写）", prefs.getString("model", "gpt-4o-mini") ?: "")
        key = field("API Key（仅保存在当前运行内存，不写入项目）", "")
        key.inputType = 129
        root.addView(endpoint); root.addView(model); root.addView(key)
        root.addView(Button(this).apply {
            text = "测试网络并保存接口设置"
            setOnClickListener {
                val url = endpoint.text.toString().trim(); val m = model.text.toString().trim()
                try { URL(url).toURI() } catch (_: Exception) { result.text = "接口地址格式不正确。"; return@setOnClickListener }
                prefs.edit().putString("endpoint", url).putString("model", m).apply()
                val k = key.text.toString().trim()
                if (k.isBlank()) { result.text = "接口地址和模型已保存。请输入 API Key 后，才能测试真实 AI 请求。"; return@setOnClickListener }
                runAi("请只回复：连接测试成功。", true)
            }
        })
        root.addView(TextView(this).apply {
            text = "二、AI 聊天分析"; textSize = 18f; setTextColor(0xFF9C4772.toInt()); setPadding(0, dp(18), 0, dp(6))
        })
        input = EditText(this).apply { hint = "粘贴对方发来的消息或客户问题"; minLines = 3; textSize = 14f }
        root.addView(input, ViewGroup.LayoutParams(-1, -2))
        root.addView(Button(this).apply { text = "联网 AI 分析并生成回复"; setOnClickListener {
            val msg = input.text.toString().trim()
            if (msg.isBlank()) result.text = "请先粘贴一条消息。" else runAi(msg, false)
        } })
        root.addView(Button(this).apply { text = "开启通知读取权限"; setOnClickListener { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) } })
        root.addView(Button(this).apply { text = "开启悬浮窗权限"; setOnClickListener {
            if (!Settings.canDrawOverlays(this@MainActivity)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } })
        result = TextView(this).apply { text = "运行状态：等待连接。\n\n提示：通知监听只读取系统实际展示的通知文字；当前联网 AI 先在本页面测试。"; textSize = 14f; setTextColor(0xFF594A52.toInt()); setPadding(0, dp(12), 0, dp(12)) }
        root.addView(result)
        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll)
    }

    private fun field(hintText: String, value: String) = EditText(this).apply {
        hint = hintText; setText(value); textSize = 13f; singleLine = true
    }

    private fun runAi(message: String, test: Boolean) {
        val url = endpoint.text.toString().trim(); val m = model.text.toString().trim(); val k = key.text.toString().trim()
        result.text = "正在连接 AI 服务，请稍候……"
        Thread {
            try {
                val answer = AiClient.chat(url, m, k, message)
                main.post { result.text = if (test) "网络与 AI 接口测试成功！\n\n$answer" else "AI 分析结果\n\n$answer\n\n请核对内容后自行决定是否发送。" }
            } catch (e: Exception) {
                main.post { result.text = "连接失败：${e.message ?: "未知错误"}\n\n请检查网络、接口地址、模型名称和 API Key。" }
            }
        }.start()
    }
}
